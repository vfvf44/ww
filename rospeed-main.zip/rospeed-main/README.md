# Roblox Claimable Group Finder
- Python software which allows you to look for ownerless & claimable groups in roblox.

# Usage
- Install Python3.11 
- Install packages from requirements.txt (`pip install -r requirements.txt`)
- Configure `Config/config.json` to your need (choose an IO module, e. g. socket)
- Fill up `Config/proxies.txt` with your HTTP/s proxies (Proxy Scraper included.)
- Run `python3 main.py`
- Enjoy

# Notes
- I didn't update this in a long time lmfao.
- Contact me on discord if there's any bugs (Discord: realnovak)
